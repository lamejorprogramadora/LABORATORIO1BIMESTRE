﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a As Integer
        a = TextBox1.Text

        If (a <= 59) Then
            TextBox2.Text = "REPROBADO"
        End If
        If (a >= 60) And (a <= 69) Then
            TextBox2.Text = "APROBADO"
        End If
        If (a >= 70) And (a <= 79) Then
            TextBox2.Text = "NOTABLE"
        End If
        If (a >= 80) And (a <= 89) Then
            TextBox2.Text = "SOBRESALIENTE"
        End If
        If (a >= 90) Then
            TextBox2.Text = "EXCELENTE"
        End If

    End Sub
End Class
