﻿Public Class Form1
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label13_Click(sender As Object, e As EventArgs) Handles Label13.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim gas As String
        Dim consumo As String
        Dim total As String
        Dim vuelto As String

        gas = 35
        consumo = Convert.ToString(TextBox1.Text)
        total = consumo * gas
        TextBox2.Text = total
        vuelto = Convert.ToString(TextBox3.Text) - total
        TextBox4.Text = vuelto


    End Sub
End Class
