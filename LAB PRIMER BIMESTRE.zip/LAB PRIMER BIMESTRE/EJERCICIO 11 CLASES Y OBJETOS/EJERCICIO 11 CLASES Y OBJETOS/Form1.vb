﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim jime As persona = New persona()
        jime.nombre = "Jimena  "
        jime.genero = "femenino "
        jime.altura = "155cm "
        jime.ciudad = "Mazatenango "
        TextBox1.Text = jime.comer("Carne Asada")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim gabi As persona = New persona()
        gabi.nombre = "Gabriela  "
        gabi.genero = "femenino "
        gabi.altura = "165cm "
        gabi.ciudad = "San Antonio "
        TextBox1.Text = gabi.dormir("5 horas")
    End Sub
End Class
