﻿Public Class persona
    'PROPIEDADES'
    Public nombre As String
    Public genero As String
    Public altura As String
    Public ciudad As String

    'CONSTRUCTOR'
    Public Sub New()

    End Sub

    Public Sub New(nombre As String, raza As String, altura As String)
        Me.nombre = nombre
        Me.genero = raza
        Me.altura = altura
        Me.ciudad = altura

    End Sub

    Public Function comer(comida As String) As String
        Return Me.nombre & "es de genero " & genero & " mide " & Me.altura & "vive en " & ciudad & " y comera " & comida

    End Function
    Public Function dormir(horas As String) As String
        Return Me.nombre & "es de genero " & genero & " mide " & Me.altura & "vive en " & ciudad & " y duerme " & horas

    End Function
End Class
